# Rank It Pro WordPress Plugin

## Installation Instructions

1. Save the rank-it-pro-plugin.php file to your computer
2. Log into your WordPress admin panel
3. Go to Plugins > Add New > Upload Plugin
4. Choose the rank-it-pro-plugin.php file and click Install Now
5. Activate the plugin
6. Go to Settings > Rank It Pro Integration
7. Enter your API credentials from your Rank It Pro dashboard
8. Configure your sync settings and save

## Configuration

- **API Key**: 0be5f789f011aa523fb275001abce54f0223c1bec4a7c4c77211d39a93d622f7
- **Webhook URL**: https://localhost:5000/api/wordpress/webhook
- **Auto Sync**: Enable to automatically publish check-ins
- **Photo Upload**: Enable to include technician photos

## Support

For support and documentation, visit your dashboard's documentation section.

## Features

- Automatic check-in publishing
- SEO-optimized post creation
- Schema.org markup for local SEO
- Photo integration
- Custom post types for service visits
- Webhook support for real-time updates

## Troubleshooting

If you experience issues:
1. Check that your API key is correct
2. Ensure your WordPress site can make outbound HTTPS requests
3. Verify the webhook URL is accessible
4. Check plugin logs in WordPress admin

Version: 1.0.0
Author: Rank It Pro
