# Rank It Pro WordPress Plugin

## Installation Instructions

1. Save the rank-it-pro-plugin.php file to your computer
2. Log into your WordPress admin panel
3. Go to Plugins > Add New > Upload Plugin
4. Choose the rank-it-pro-plugin.php file and click Install Now
5. Activate the plugin
6. Go to Settings > Rank It Pro Integration
7. Enter your API credentials from your Rank It Pro dashboard
8. Configure your sync settings and save

## Configuration

- **API Key**: 9cb92acfdb28849701b491b9b7ed2c67e815af96b829d4a7917fe68d8c5c725d
- **Webhook URL**: https://3ba12234-e3a1-4984-9152-1724cec12a3c-00-3d1awbp5bhqqy.kirk.replit.dev/api/wordpress/webhook
- **Auto Sync**: Enable to automatically publish check-ins
- **Photo Upload**: Enable to include technician photos

## Support

For support and documentation, visit your dashboard's documentation section.

## Features

- Automatic check-in publishing
- SEO-optimized post creation
- Schema.org markup for local SEO
- Photo integration
- Custom post types for service visits
- Webhook support for real-time updates

## Troubleshooting

If you experience issues:
1. Check that your API key is correct
2. Ensure your WordPress site can make outbound HTTPS requests
3. Verify the webhook URL is accessible
4. Check plugin logs in WordPress admin

Version: 1.0.0
Author: Rank It Pro
