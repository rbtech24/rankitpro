<?php
/**
 * Plugin Name: Rank it Pro Integration
 * Description: Integrates with Rank it Pro to display technician visits on your website
 * Version: 1.0.0
 * Author: Rank it Pro
 * Text Domain: rankitpro
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class RankItPro_Visit_Integration {
    private $apiKey;
    private $apiEndpoint;

    private $reviewsEndpoint;

    public function __construct() {
        $this->apiKey = get_option('rankitpro_api_key', '');
        $this->apiEndpoint = get_option('rankitpro_api_endpoint', 'https://3ba12234-e3a1-4984-9152-1724cec12a3c-00-3d1awbp5bhqqy.kirk.replit.dev/') . 'api/wordpress/public/visits';
        $this->reviewsEndpoint = get_option('rankitpro_api_endpoint', 'https://3ba12234-e3a1-4984-9152-1724cec12a3c-00-3d1awbp5bhqqy.kirk.replit.dev/') . 'api/wordpress/public/reviews';
        
        // Register activation/deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate_plugin'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate_plugin'));
        
        // Register shortcodes
        add_shortcode('rankitpro_visits', array($this, 'rankitpro_visits_shortcode'));
        add_shortcode('rankitpro_reviews', array($this, 'rankitpro_reviews_shortcode'));
        
        // Register widget
        add_action('widgets_init', array($this, 'register_rankitpro_visits_widget'));
        
        // Add settings page
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_plugin_settings'));
        
        // Enqueue styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_styles'));
        
        // Add admin notices
        add_action('admin_notices', array($this, 'admin_notices'));
        
        // Load text domain for translations
        add_action('plugins_loaded', array($this, 'load_textdomain'));
    }
    
    // Load plugin text domain for translations
    public function load_textdomain() {
        load_plugin_textdomain('rankitpro', false, dirname(plugin_basename(__FILE__)) . '/languages/');
    }
    
    // Plugin activation
    public function activate_plugin() {
        // Set default options
        add_option('rankitpro_api_key', '');
        add_option('rankitpro_api_endpoint', 'https://3ba12234-e3a1-4984-9152-1724cec12a3c-00-3d1awbp5bhqqy.kirk.replit.dev/');
        add_option('rankitpro_auto_sync', '1');
        add_option('rankitpro_show_photos', '1');
        add_option('rankitpro_cache_duration', '3600');
        
        // Create database table for local cache if needed
        global $wpdb;
        $table_name = $wpdb->prefix . 'rankitpro_cache';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            cache_key varchar(255) NOT NULL,
            cache_value longtext NOT NULL,
            expires datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY cache_key (cache_key)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Flush rewrite rules
        flush_rewrite_rules();
        
        // Set activation notice
        set_transient('rankitpro_activation_notice', true, 5);
    }
    
    // Plugin deactivation
    public function deactivate_plugin() {
        // Clear any scheduled events
        wp_clear_scheduled_hook('rankitpro_sync_data');
        
        // Flush rewrite rules
        flush_rewrite_rules();
        
        // Clean up transients
        delete_transient('rankitpro_activation_notice');
        delete_transient('rankitpro_api_status');
    }
    
    // Register plugin settings
    public function register_plugin_settings() {
        // Register setting group
        register_setting('rankitpro_settings_group', 'rankitpro_api_key', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => ''
        ));
        
        register_setting('rankitpro_settings_group', 'rankitpro_api_endpoint', array(
            'type' => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default' => 'https://3ba12234-e3a1-4984-9152-1724cec12a3c-00-3d1awbp5bhqqy.kirk.replit.dev/'
        ));
        
        register_setting('rankitpro_settings_group', 'rankitpro_auto_sync', array(
            'type' => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => true
        ));
        
        register_setting('rankitpro_settings_group', 'rankitpro_show_photos', array(
            'type' => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => true
        ));
        
        register_setting('rankitpro_settings_group', 'rankitpro_cache_duration', array(
            'type' => 'integer',
            'sanitize_callback' => 'absint',
            'default' => 3600
        ));
        
        // Add settings sections
        add_settings_section(
            'rankitpro_api_section',
            __('API Configuration', 'rankitpro'),
            array($this, 'api_section_callback'),
            'rankitpro-settings'
        );
        
        add_settings_section(
            'rankitpro_display_section',
            __('Display Options', 'rankitpro'),
            array($this, 'display_section_callback'),
            'rankitpro-settings'
        );
        
        // Add settings fields
        add_settings_field(
            'rankitpro_api_key',
            __('API Key', 'rankitpro'),
            array($this, 'api_key_field_callback'),
            'rankitpro-settings',
            'rankitpro_api_section'
        );
        
        add_settings_field(
            'rankitpro_api_endpoint',
            __('API Endpoint', 'rankitpro'),
            array($this, 'api_endpoint_field_callback'),
            'rankitpro-settings',
            'rankitpro_api_section'
        );
        
        add_settings_field(
            'rankitpro_auto_sync',
            __('Auto Sync', 'rankitpro'),
            array($this, 'auto_sync_field_callback'),
            'rankitpro-settings',
            'rankitpro_api_section'
        );
        
        add_settings_field(
            'rankitpro_show_photos',
            __('Show Photos', 'rankitpro'),
            array($this, 'show_photos_field_callback'),
            'rankitpro-settings',
            'rankitpro_display_section'
        );
        
        add_settings_field(
            'rankitpro_cache_duration',
            __('Cache Duration (seconds)', 'rankitpro'),
            array($this, 'cache_duration_field_callback'),
            'rankitpro-settings',
            'rankitpro_display_section'
        );
    }
    
    // Settings section callbacks
    public function api_section_callback() {
        echo '<p>' . __('Configure your Rank It Pro API connection settings.', 'rankitpro') . '</p>';
    }
    
    public function display_section_callback() {
        echo '<p>' . __('Customize how your check-ins and reviews are displayed.', 'rankitpro') . '</p>';
    }
    
    // Settings field callbacks
    public function api_key_field_callback() {
        $value = get_option('rankitpro_api_key', '');
        echo '<input type="text" id="rankitpro_api_key" name="rankitpro_api_key" value="' . esc_attr($value) . '" class="regular-text" placeholder="' . __('Enter your API key', 'rankitpro') . '" />';
        echo '<p class="description">' . __('Your unique API key from Rank It Pro dashboard.', 'rankitpro') . '</p>';
    }
    
    public function api_endpoint_field_callback() {
        $value = get_option('rankitpro_api_endpoint', 'https://3ba12234-e3a1-4984-9152-1724cec12a3c-00-3d1awbp5bhqqy.kirk.replit.dev/');
        echo '<input type="url" id="rankitpro_api_endpoint" name="rankitpro_api_endpoint" value="' . esc_attr($value) . '" class="regular-text" />';
        echo '<p class="description">' . __('Your Rank It Pro API endpoint URL.', 'rankitpro') . '</p>';
    }
    
    public function auto_sync_field_callback() {
        $value = get_option('rankitpro_auto_sync', true);
        echo '<input type="checkbox" id="rankitpro_auto_sync" name="rankitpro_auto_sync" value="1"' . checked(1, $value, false) . ' />';
        echo '<label for="rankitpro_auto_sync">' . __('Automatically sync new check-ins', 'rankitpro') . '</label>';
    }
    
    public function show_photos_field_callback() {
        $value = get_option('rankitpro_show_photos', true);
        echo '<input type="checkbox" id="rankitpro_show_photos" name="rankitpro_show_photos" value="1"' . checked(1, $value, false) . ' />';
        echo '<label for="rankitpro_show_photos">' . __('Display photos in check-ins', 'rankitpro') . '</label>';
    }
    
    public function cache_duration_field_callback() {
        $value = get_option('rankitpro_cache_duration', 3600);
        echo '<input type="number" id="rankitpro_cache_duration" name="rankitpro_cache_duration" value="' . esc_attr($value) . '" min="300" max="86400" class="small-text" />';
        echo '<p class="description">' . __('How long to cache API responses (300-86400 seconds).', 'rankitpro') . '</p>';
    }
    
    // Admin notices
    public function admin_notices() {
        // Show activation notice
        if (get_transient('rankitpro_activation_notice')) {
            echo '<div class="notice notice-success is-dismissible">';
            echo '<p>' . __('Rank It Pro plugin activated successfully! Configure your settings to get started.', 'rankitpro') . '</p>';
            echo '</div>';
            delete_transient('rankitpro_activation_notice');
        }
        
        // Check API connection and show notice if failed
        $api_status = get_transient('rankitpro_api_status');
        if ($api_status === false) {
            $connection_test = $this->test_api_connection();
            set_transient('rankitpro_api_status', $connection_test ? 'connected' : 'failed', 300);
            $api_status = $connection_test ? 'connected' : 'failed';
        }
        
        if ($api_status === 'failed') {
            echo '<div class="notice notice-error">';
            echo '<p>' . __('Rank It Pro API connection failed. Please check your API key in the settings.', 'rankitpro') . '</p>';
            echo '</div>';
        }
    }
    
    public function enqueue_styles() {
        // Add some basic styles
        wp_add_inline_style('wp-block-library', '
            .rankitpro-visit-list {
                list-style: none;
                padding: 0;
                margin: 0 0 20px 0;
            }
            .rankitpro-visit-item {
                border: 1px solid #e5e5e5;
                border-radius: 5px;
                padding: 15px;
                margin-bottom: 15px;
                background: #f9f9f9;
            }
            .rankitpro-visit-meta {
                font-size: 0.8em;
                color: #666;
                margin-top: 10px;
            }
            .rankitpro-visit-title {
                font-weight: bold;
                font-size: 1.1em;
                margin-bottom: 10px;
            }
            .rankitpro-visit-photos {
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
                margin-top: 10px;
            }
            .rankitpro-visit-photo {
                width: 100px;
                height: 100px;
                object-fit: cover;
                border-radius: 3px;
            }
            .rankitpro-review-list {
                list-style: none;
                padding: 0;
                margin: 0 0 20px 0;
            }
            .rankitpro-review-item {
                border: 1px solid #e5e5e5;
                border-radius: 8px;
                padding: 20px;
                margin-bottom: 20px;
                background: #fff;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            .rankitpro-review-header {
                display: flex;
                justify-content: space-between;
                align-items: flex-start;
                margin-bottom: 15px;
            }
            .rankitpro-customer-name {
                font-weight: bold;
                font-size: 1.1em;
                color: #333;
            }
            .rankitpro-review-rating {
                color: #ffc107;
                font-size: 16px;
            }
            .rankitpro-review-feedback {
                font-style: italic;
                color: #555;
                margin: 15px 0;
                padding: 0 20px;
                border-left: 3px solid #007cba;
            }
            .rankitpro-review-service,
            .rankitpro-review-tech {
                font-size: 14px;
                color: #666;
                margin: 5px 0;
            }
            .rankitpro-review-date {
                text-align: right;
                font-size: 12px;
                color: #999;
                margin-top: 15px;
            }
        ');
    }
    
    public function rankitpro_visits_shortcode($atts) {
        $atts = shortcode_atts(array(
            'limit' => 5,
            'type' => 'all'
        ), $atts);
        
        $check_ins = $this->get_check_ins($atts['limit'], $atts['type']);
        
        if (empty($check_ins)) {
            return '<p>' . __('No recent visits available.', 'rankitpro') . '</p>';
        }
        
        $output = '<div class="rankitpro-visits-container">';
        $output .= '<ul class="rankitpro-visit-list">';
        
        foreach ($check_ins as $check_in) {
            $date = date('F j, Y', strtotime($check_in->createdAt));
            $time = date('g:i A', strtotime($check_in->createdAt));
            
            $output .= '<li class="rankitpro-visit-item">';
            $output .= '<div class="rankitpro-visit-title">' . esc_html($check_in->jobType) . '</div>';
            
            if (!empty($check_in->notes)) {
                $output .= '<div class="rankitpro-visit-notes">' . esc_html($check_in->notes) . '</div>';
            }
            
            if (!empty($check_in->location)) {
                $output .= '<div class="rankitpro-visit-location">Location: ' . esc_html($check_in->location) . '</div>';
            }
            
            // Display photos if available
            if (!empty($check_in->photoUrls) && is_array($check_in->photoUrls)) {
                $output .= '<div class="rankitpro-visit-photos">';
                foreach ($check_in->photoUrls as $photoUrl) {
                    $output .= '<img class="rankitpro-visit-photo" src="' . esc_url($photoUrl) . '" alt="Visit photo" />';
                }
                $output .= '</div>';
            }
            
            $output .= '<div class="rankitpro-visit-meta">' . $date . ' at ' . $time . '</div>';
            $output .= '</li>';
        }
        
        $output .= '</ul>';
        $output .= '</div>';
        
        return $output;
    }
    
    public function rankitpro_reviews_shortcode($atts) {
        $atts = shortcode_atts(array(
            'limit' => 5,
            'rating' => 'all',
            'show_photos' => 'true'
        ), $atts);
        
        $reviews = $this->get_reviews($atts['limit'], $atts['rating']);
        
        if (empty($reviews)) {
            return '<p>' . __('No customer reviews available.', 'rankitpro') . '</p>';
        }
        
        $output = '<div class="rankitpro-reviews-container">';
        $output .= '<ul class="rankitpro-review-list">';
        
        foreach ($reviews as $review) {
            $date = date('F j, Y', strtotime($review->respondedAt));
            $stars = str_repeat('★', $review->rating) . str_repeat('☆', 5 - $review->rating);
            
            $output .= '<li class="rankitpro-review-item">';
            $output .= '<div class="rankitpro-review-header">';
            $output .= '<div class="rankitpro-customer-name">' . esc_html($review->customerName) . '</div>';
            $output .= '<div class="rankitpro-review-rating">' . $stars . ' (' . $review->rating . '/5)</div>';
            $output .= '</div>';
            
            if (!empty($review->feedback)) {
                $output .= '<div class="rankitpro-review-feedback">"' . esc_html($review->feedback) . '"</div>';
            }
            
            if (!empty($review->jobType)) {
                $output .= '<div class="rankitpro-review-service">Service: ' . esc_html($review->jobType) . '</div>';
            }
            
            if (!empty($review->technicianName)) {
                $output .= '<div class="rankitpro-review-tech">Technician: ' . esc_html($review->technicianName) . '</div>';
            }
            
            $output .= '<div class="rankitpro-review-date">' . $date . '</div>';
            $output .= '</li>';
        }
        
        $output .= '</ul>';
        $output .= '</div>';
        
        return $output;
    }
    
    private function get_check_ins($limit = 5, $type = 'all') {
        $url = add_query_arg(array(
            'apiKey' => $this->apiKey,
            'limit' => $limit,
            'type' => $type
        ), $this->apiEndpoint);
        
        $response = wp_remote_get($url);
        
        if (is_wp_error($response)) {
            error_log('Rank it Pro Integration: API request failed - ' . $response->get_error_message());
            return array();
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body);
        
        if (empty($data) || is_wp_error($data)) {
            return array();
        }
        
        return $data;
    }
    
    private function get_reviews($limit = 5, $rating = 'all') {
        $url = add_query_arg(array(
            'apiKey' => $this->apiKey,
            'limit' => $limit,
            'rating' => $rating
        ), $this->reviewsEndpoint);
        
        $response = wp_remote_get($url);
        
        if (is_wp_error($response)) {
            error_log('Rank it Pro Integration: Reviews API request failed - ' . $response->get_error_message());
            return array();
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body);
        
        if (empty($data) || is_wp_error($data)) {
            return array();
        }
        
        return $data;
    }
    
    public function register_rankitpro_visits_widget() {
        register_widget('RankItPro_Visits_Widget');
    }
    
    public function add_admin_menu() {
        add_options_page(
            'Rank it Pro Settings',
            'Rank it Pro Settings',
            'manage_options',
            'rankitpro-visits-settings',
            array($this, 'display_settings_page')
        );
    }
    
    public function display_settings_page() {
        // Handle form submission
        if (isset($_POST['submit']) && check_admin_referer('rankitpro_settings_nonce')) {
            $this->handle_settings_save();
        }
        
        ?>
        <div class="wrap">
            <h1><?php _e('Rank It Pro Integration Settings', 'rankitpro'); ?></h1>
            
            <form method="post" action="">
                <?php 
                settings_fields('rankitpro_settings_group');
                do_settings_sections('rankitpro-settings');
                wp_nonce_field('rankitpro_settings_nonce');
                submit_button(__('Save Settings', 'rankitpro'));
                ?>
            </form>
            
            <div class="card">
                <h2><?php _e('How to Use', 'rankitpro'); ?></h2>
                <p><?php _e('Use shortcodes to display your technician visits and customer reviews anywhere on your site.', 'rankitpro'); ?></p>
                
                <h3><?php _e('Available Shortcodes', 'rankitpro'); ?></h3>
                <table class="widefat">
                    <thead>
                        <tr>
                            <th><?php _e('Shortcode', 'rankitpro'); ?></th>
                            <th><?php _e('Description', 'rankitpro'); ?></th>
                            <th><?php _e('Parameters', 'rankitpro'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><code>[rankitpro_visits]</code></td>
                            <td><?php _e('Display recent technician visits', 'rankitpro'); ?></td>
                            <td>limit, type</td>
                        </tr>
                        <tr>
                            <td><code>[rankitpro_reviews]</code></td>
                            <td><?php _e('Display customer reviews and testimonials', 'rankitpro'); ?></td>
                            <td>limit, rating, show_photos</td>
                        </tr>
                    </tbody>
                </table>
                
                <h3><?php _e('Examples', 'rankitpro'); ?></h3>
                <ul>
                    <li><code>[rankitpro_visits limit="3" type="Plumbing"]</code> - <?php _e('Show 3 latest plumbing visits', 'rankitpro'); ?></li>
                    <li><code>[rankitpro_reviews limit="5" rating="5"]</code> - <?php _e('Show 5 five-star reviews', 'rankitpro'); ?></li>
                </ul>
            </div>
            
            <div class="card" style="margin-top: 20px;">
                <h2><?php _e('API Connection Status', 'rankitpro'); ?></h2>
                <p><?php _e('Status:', 'rankitpro'); ?> <strong><?php echo $this->test_api_connection() ? __('Connected', 'rankitpro') : __('Not Connected', 'rankitpro'); ?></strong></p>
                <?php 
                $api_key = get_option('rankitpro_api_key', '');
                $api_endpoint = get_option('rankitpro_api_endpoint', 'https://3ba12234-e3a1-4984-9152-1724cec12a3c-00-3d1awbp5bhqqy.kirk.replit.dev/');
                ?>
                <p><?php _e('API Key:', 'rankitpro'); ?> <code><?php 
                    if (!empty($api_key)) {
                        echo esc_html(substr($api_key, 0, 8) . '...' . substr($api_key, -4));
                    } else {
                        echo __('Not configured', 'rankitpro');
                    }
                ?></code></p>
                <p><?php _e('Endpoint:', 'rankitpro'); ?> <code><?php echo esc_html($api_endpoint); ?></code></p>
                
                <p>
                    <button type="button" class="button button-secondary" onclick="testApiConnection()"><?php _e('Test Connection', 'rankitpro'); ?></button>
                    <span id="connection-test-result"></span>
                </p>
            </div>
            
            <script>
            function testApiConnection() {
                const button = document.querySelector('button[onclick="testApiConnection()"]');
                const result = document.getElementById('connection-test-result');
                
                button.disabled = true;
                button.textContent = '<?php _e('Testing...', 'rankitpro'); ?>';
                result.innerHTML = '';
                
                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'action=rankitpro_test_connection&nonce=' + '<?php echo wp_create_nonce('rankitpro_test_nonce'); ?>'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        result.innerHTML = '<span style="color: green;">✓ <?php _e('Connection successful!', 'rankitpro'); ?></span>';
                    } else {
                        result.innerHTML = '<span style="color: red;">✗ <?php _e('Connection failed:', 'rankitpro'); ?> ' + data.data + '</span>';
                    }
                })
                .catch(error => {
                    result.innerHTML = '<span style="color: red;">✗ <?php _e('Error testing connection', 'rankitpro'); ?></span>';
                })
                .finally(() => {
                    button.disabled = false;
                    button.textContent = '<?php _e('Test Connection', 'rankitpro'); ?>';
                });
            }
            </script>
        </div>
        <?php
    }
    
    // Handle settings save with proper nonce validation
    private function handle_settings_save() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'rankitpro'));
        }
        
        // Update options with sanitization
        if (isset($_POST['rankitpro_api_key'])) {
            update_option('rankitpro_api_key', sanitize_text_field($_POST['rankitpro_api_key']));
        }
        
        if (isset($_POST['rankitpro_api_endpoint'])) {
            update_option('rankitpro_api_endpoint', esc_url_raw($_POST['rankitpro_api_endpoint']));
        }
        
        if (isset($_POST['rankitpro_auto_sync'])) {
            update_option('rankitpro_auto_sync', '1');
        } else {
            update_option('rankitpro_auto_sync', '0');
        }
        
        if (isset($_POST['rankitpro_show_photos'])) {
            update_option('rankitpro_show_photos', '1');
        } else {
            update_option('rankitpro_show_photos', '0');
        }
        
        if (isset($_POST['rankitpro_cache_duration'])) {
            $cache_duration = absint($_POST['rankitpro_cache_duration']);
            if ($cache_duration >= 300 && $cache_duration <= 86400) {
                update_option('rankitpro_cache_duration', $cache_duration);
            }
        }
        
        // Clear API status cache to force recheck
        delete_transient('rankitpro_api_status');
        
        // Show success message
        add_settings_error('rankitpro_messages', 'rankitpro_message', __('Settings saved successfully!', 'rankitpro'), 'success');
    }
    
    private function test_api_connection() {
        $url = add_query_arg(array(
            'apiKey' => $this->apiKey,
            'limit' => 1
        ), $this->apiEndpoint);
        
        $response = wp_remote_get($url);
        
        if (is_wp_error($response)) {
            return false;
        }
        
        $code = wp_remote_retrieve_response_code($response);
        return $code === 200;
    }
}

class RankItPro_Visits_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct(
            'rankitpro_visits_widget',
            __('Recent Visits', 'rankitpro'),
            array('description' => __('Display your recent technician visits', 'rankitpro'))
        );
    }
    
    public function widget($args, $instance) {
        $title = !empty($instance['title']) ? $instance['title'] : 'Recent Visits';
        $limit = !empty($instance['limit']) ? $instance['limit'] : 3;
        $type = !empty($instance['type']) ? $instance['type'] : 'all';
        
        echo $args['before_widget'];
        echo $args['before_title'] . esc_html($title) . $args['after_title'];
        
        echo do_shortcode('[rankitpro_visits limit="' . esc_attr($limit) . '" type="' . esc_attr($type) . '"]');
        
        echo $args['after_widget'];
    }
    
    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : 'Recent Visits';
        $limit = !empty($instance['limit']) ? $instance['limit'] : 3;
        $type = !empty($instance['type']) ? $instance['type'] : 'all';
        
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>">Title:</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('limit')); ?>">Number of visits to show:</label>
            <input class="tiny-text" id="<?php echo esc_attr($this->get_field_id('limit')); ?>" name="<?php echo esc_attr($this->get_field_name('limit')); ?>" type="number" step="1" min="1" value="<?php echo esc_attr($limit); ?>" size="3">
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('type')); ?>">Job Type (or 'all' for all types):</label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('type')); ?>" name="<?php echo esc_attr($this->get_field_name('type')); ?>" type="text" value="<?php echo esc_attr($type); ?>">
        </p>
        <?php
    }
    
    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = !empty($new_instance['title']) ? sanitize_text_field($new_instance['title']) : 'Recent Check-Ins';
        $instance['limit'] = !empty($new_instance['limit']) ? absint($new_instance['limit']) : 3;
        $instance['type'] = !empty($new_instance['type']) ? sanitize_text_field($new_instance['type']) : 'all';
        
        return $instance;
    }
}

// Initialize the plugin
new RankItPro_Visit_Integration();
